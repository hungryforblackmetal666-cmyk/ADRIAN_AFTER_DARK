define a = Character("Adrian", color="#d7c4a3")
define narrator = Character(None)
define raven = Character("Raven", color="#b7a0d8")
define victoria = Character("Victoria", color="#d8c1a1")
define alex = Character("Alex", color="#a6c7dc")
define barbie = Character("Barbie", color="#f1a9c7")
define lilith = Character("Lilith", color="#c6a4d8")
define system = Character("SYSTEM", color="#85b9bd")

default day = 1
default hour = 8
default money = 12500
default energy = 100
default reputation = 50
default suspicion = 0
default chapter1_done = False
default route_flags = {}
default relationships = {"Raven": 0, "Victoria": 0, "Lilith": 0, "Alex": 0, "Barbie": 0}
default inventory = ["Phone", "Penthouse key", "Company access card"]
default clues = []
default messages = ["08:02 — Unknown: We need to talk before the board meeting."]
default visited_today = []
default language = "EN"
default first_choice = "none"
default raven_boundary_respected = False

init python:
    def add_clue(clue):
        if clue not in clues:
            clues.append(clue)

    def add_item(item):
        if item not in inventory:
            inventory.append(item)

    def change_rel(name, amount):
        relationships[name] = relationships.get(name, 0) + amount

    def advance_time(hours=1):
        global hour, day, energy, visited_today
        hour += hours
        energy = max(0, energy - 5 * hours)
        while hour >= 24:
            hour -= 24
            day += 1
            visited_today = []

    def time_label():
        return "%02d:00" % hour

label start:
    call screen title_gate
    scene black
    with fade
    centered "{size=+18}ADRIAN: AFTER DARK{/size}\n{color=#b9a88e}SANDBOX EDITION{/color}"
    pause 1.0
    narrator "A city built on glass, money and carefully buried secrets."
    narrator "You are Adrian Vale, thirty years old, CEO of Vale International."
    narrator "Tonight, a message arrives that could dismantle everything you have built."
    jump prologue

label prologue:
    scene bg penthouse
    with dissolve
    system "MONDAY — 08:02"
    "Your phone vibrates on the marble counter."
    "UNKNOWN: We need to talk before the board meeting. I have proof about the acquisition."
    menu:
        "Reply: Who is this?":
            $ messages.append("08:04 — You: Who is this?")
            $ first_choice = "direct"
            $ suspicion += 1
        "Reply: Name a place.":
            $ messages.append("08:04 — You: Name a place.")
            $ first_choice = "controlled"
            $ reputation += 1
        "Ignore the message for now.":
            $ first_choice = "ignore"
            $ suspicion += 1
    "The city waits below your windows. Your assistant has already sent the day's schedule."
    jump chapter_one_intro

label chapter_one_intro:
    scene bg penthouse
    "You have a board meeting at 18:00. Until then, the city is yours to navigate."
    "Build trust, find out who is threatening the company, and decide what kind of man Adrian Vale will be."
    jump city_hub

label city_hub:
    scene bg city
    with dissolve
    show screen hud_screen
    call screen city_screen
    hide screen hud_screen
    jump city_hub

label visit_hq:
    scene bg hq
    with dissolve
    show victoria_bust at character_right
    $ advance_time(1)
    "The executive floor is quiet, but the silence feels staged."
    victoria "Mr. Vale. The board has requested the acquisition documents."
    menu:
        "Ask Victoria what she knows.":
            $ change_rel("Victoria", 2)
            $ add_clue("Acquisition file discrepancy")
            victoria "Three signatures were added after the final review. I can prove it, but not here."
            "Victoria slides a note across the desk."
            $ add_item("Victoria's sealed note")
        "Demand the documents immediately.":
            $ reputation += 2
            $ change_rel("Victoria", -1)
            victoria "Of course. I will have them sent."
            "Her expression gives nothing away."
        "Ask her to join you for a private, professional review.":
            $ change_rel("Victoria", 1)
            victoria "That would be the sensible choice. With clear boundaries and a written record."
    hide victoria_bust
    jump city_hub

label visit_nocturne:
    scene bg club
    with dissolve
    show raven_bust at character_right
    $ advance_time(1)
    raven "Adrian Vale. I wondered when you'd come looking."
    "Raven runs the Nocturne, a private club where the city's influential people trade favors."
    menu:
        "Ask about the anonymous message.":
            $ change_rel("Raven", 2)
            $ add_clue("Raven knows the sender")
            raven "I know who sent it. But information has a price."
        "Offer a business favor in exchange for information.":
            $ money -= 500
            $ change_rel("Raven", 1)
            raven "A clean transaction. I can respect that."
            $ add_clue("Club guest list")
        "Push for answers and ignore her rules.":
            $ suspicion += 2
            $ change_rel("Raven", -2)
            raven "No. You don't get to decide my boundaries."
            "She ends the conversation."
    hide raven_bust
    jump city_hub

label visit_lilith:
    scene bg cafe
    with dissolve
    show lilith_bust at character_right
    $ advance_time(1)
    lilith "Welcome to the studio. Around here, every mark has a story."
    "Lilith owns an independent tattoo studio and knows the city's underground art scene."
    menu:
        "Ask about a symbol seen in the acquisition files.":
            $ change_rel("Lilith", 2)
            $ add_clue("Tattoo symbol linked to the acquisition")
            lilith "I've seen that mark before. It belongs to a private collectors' circle."
        "Ask her about the artists she works with.":
            $ change_rel("Lilith", 1)
            lilith "Artists hear things people in boardrooms never will."
        "Demand that she tell you everything she knows.":
            $ change_rel("Lilith", -2)
            lilith "This is my studio. Respect is the price of entry."
    hide lilith_bust
    jump city_hub

label visit_cafe:
    scene bg cafe
    with dissolve
    $ advance_time(1)
    alex "You're not exactly subtle, you know."
    "Alex is a freelance photographer who has been documenting the city's private events."
    menu:
        "Ask to see her recent photographs.":
            $ change_rel("Alex", 2)
            $ add_clue("Photograph of a late-night meeting")
            alex "One image might interest you. I haven't published it."
        "Offer to buy her archive.":
            $ money -= 800
            $ change_rel("Alex", 1)
            $ add_item("Encrypted photo archive")
            alex "You'll get a copy. The originals stay with me."
        "Ask why she is following your company.":
            $ change_rel("Alex", -1)
            alex "Because somebody should be asking questions."
    jump city_hub

label visit_penthouse:
    scene bg penthouse
    with dissolve
    $ advance_time(1)
    "Your penthouse is the only place where the city sounds distant."
    menu:
        "Rest for two hours.":
            $ advance_time(2)
            $ energy = min(100, energy + 35)
            "You get some much-needed rest."
        "Review the clues.":
            if len(clues) == 0:
                "You don't have any solid clues yet."
            else:
                "You review the evidence you've collected: [', '.join(clues)]."
        "Check your wardrobe.":
            call screen wardrobe_screen
    jump city_hub

label phone_menu:
    call screen phone_screen
    jump city_hub

label inventory_menu:
    call screen inventory_screen
    jump city_hub

label end_day:
    if hour < 18:
        "The board meeting is scheduled for 18:00. There is still time to prepare."
        jump city_hub
    jump board_meeting

label board_meeting:
    scene bg hq
    with fade
    "18:00 — BOARDROOM"
    "Seven executives take their seats. Every one of them is watching you."
    if "Acquisition file discrepancy" in clues and "Photograph of a late-night meeting" in clues:
        "You place the discrepancy report beside Alex's photograph."
        "The room falls silent. The acquisition is suspended pending an investigation."
        $ reputation += 10
        $ add_clue("Board investigation opened")
        "You have bought yourself time — and made powerful enemies."
    elif len(clues) > 0:
        "You present what you have. The board agrees to delay the vote for twenty-four hours."
        $ reputation += 4
    else:
        "You have no evidence. The board proceeds with the vote, and you lose control of the room."
        $ reputation -= 8
        $ suspicion += 2
    $ chapter1_done = True
    jump chapter_one_ending

label chapter_one_ending:
    scene bg city
    with fade
    centered "{size=+12}CHAPTER ONE COMPLETE{/size}"
    "The city lights flicker beneath your office windows."
    "Someone wanted you to find the truth. Someone else wanted you to fail."
    "Your next move will decide who stands beside you when the pressure rises."
    menu:
        "Continue exploring the sandbox":
            jump city_hub
        "Return to the main menu":
            return

label wardrobe_return:
    jump city_hub
