ADRIAN: AFTER DARK – SANDBOX EDITION
Versiunea 1.0 – prototip narativ jucabil Ren'Py

CE ESTE ACEASTĂ VERSIUNE
- Un vertical slice jucabil: prolog + primul capitol.
- Hub urban cu patru locații.
- Timp, bani, relații, indicii, inventar și telefon.
- 15 personaje pregătite în baza de date; în această versiune, câteva au scene introductive.
- Alegeri cu consecințe și două finaluri pentru primul capitol.
- Dialoguri în engleză, cu schelet de localizare română pregătit.

LIMITĂRI ONESTE
Aceasta nu este încă versiunea comercială completă. Nu include încă 15 rute complete,
grafică 3D finală, animații, voice acting sau muzică licențiată. Imaginile placeholder
sunt intenționat înlocuite de fundaluri colorate și text, astfel încât proiectul să
poată fi rulat fără fișiere media externe.

RULARE PE PC
1. Instalează Ren'Py SDK de pe site-ul oficial renpy.org.
2. Deschide Ren'Py Launcher.
3. Alege "Preferences" / "Projects Directory" dacă este nevoie.
4. Plasează folderul ADRIAN_AFTER_DARK_v1_0 în directorul proiectelor.
5. Selectează proiectul și apasă Launch Project.

ANDROID
APK-ul nu este inclus în arhivă. Trebuie generat prin Build Distributions din Ren'Py
Launcher, după configurarea Android SDK/RAPT. Pentru utilizare fără PC, cea mai
realistă rută este o compilare în cloud; pașii vor fi adaptați separat pentru telefon.

CONTROALE
- Atinge/click pe dialog pentru a continua.
- Folosește butoanele de pe ecran pentru locații, telefon și inventar.
- Jocul salvează automat prin sistemul standard Ren'Py; poți folosi și meniul Save.

LICENȚĂ
Codul proiectului este furnizat pentru dezvoltare personală și modificare.
