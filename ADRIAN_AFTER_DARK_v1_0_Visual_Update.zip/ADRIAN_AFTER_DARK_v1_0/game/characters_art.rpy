# Character artwork — first integration set.
image raven_bust = "images/characters/raven_bust.webp"
image raven_full = "images/characters/raven_full.webp"
image victoria_bust = "images/characters/victoria_bust.webp"
image victoria_full = "images/characters/victoria_full.webp"
image lilith_bust = "images/characters/lilith_bust.webp"
image lilith_full = "images/characters/lilith_full.webp"

transform character_right:
    xalign 0.98
    yalign 0.98
    ysize 760
    fit "contain"
