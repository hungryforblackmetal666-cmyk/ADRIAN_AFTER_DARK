# Cinematic 16:9 location backgrounds for ADRIAN: AFTER DARK.
image bg penthouse = "images/backgrounds/penthouse.jpg"
image bg city = "images/backgrounds/city.jpg"
image bg hq = "images/backgrounds/hq.jpg"
image bg club = "images/backgrounds/club.jpg"
image bg cafe = "images/backgrounds/cafe.jpg"
