init -2:
    define gui.accent_color = '#b99b72'
    define gui.idle_color = '#a6a6a6'
    define gui.hover_color = '#e4c99b'
    define gui.selected_color = '#d9c4a0'
    define gui.insensitive_color = '#666666'
    define gui.muted_color = '#4b5059'
    define gui.hover_muted_color = '#6a707b'
    define gui.text_color = '#e7e2d8'
    define gui.interface_text_color = '#e7e2d8'
    define gui.text_size = 24
    define gui.name_text_size = 30
    define gui.label_text_size = 26
    define gui.button_text_size = 20
    define gui.choice_button_text_size = 22
    define gui.interface_text_size = 20
