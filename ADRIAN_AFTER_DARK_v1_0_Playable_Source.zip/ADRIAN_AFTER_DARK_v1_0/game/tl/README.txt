LOCALIZATION
The game uses Ren'Py's _() translation wrapper for project metadata.
Most current dialogue is English. Romanian translation can be added through
Ren'Py Launcher > Generate Translations, then editing game/tl/romanian/.
