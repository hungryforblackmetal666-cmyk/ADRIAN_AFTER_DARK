# Chapter one scenes are in script.rpy for easy editing.
# Future chapters can be added as separate .rpy files and called with Jump().
