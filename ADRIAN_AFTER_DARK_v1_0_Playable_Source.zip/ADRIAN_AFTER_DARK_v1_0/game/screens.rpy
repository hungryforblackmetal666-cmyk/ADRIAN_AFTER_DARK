screen hud_screen():
    zorder 100
    frame:
        xalign 0.02
        yalign 0.02
        background "#10131de8"
        padding (14, 8)
        vbox:
            text "DAY [day]  •  [time_label()]" size 18 color "#e9dfcf"
            text "Funds: $[money]   Energy: [energy]%" size 15 color "#b9c7c8"
            text "Reputation: [reputation]   Suspicion: [suspicion]" size 14 color "#c5a9a9"

screen city_screen():
    modal True
    frame:
        xalign 0.5
        yalign 0.53
        xsize 780
        background "#111521ee"
        padding (30, 25)
        vbox:
            spacing 12
            text "THE CITY" size 34 color "#d9c4a0"
            text "Choose where Adrian goes next." color "#d7d5d0"
            grid 2 2:
                spacing 12
                xfill True
                textbutton "VALE INTERNATIONAL — HQ" action Jump("visit_hq")
                textbutton "THE NOCTURNE — PRIVATE CLUB" action Jump("visit_nocturne")
                textbutton "CAFÉ SABLE" action Jump("visit_cafe")
                textbutton "PENTHOUSE" action Jump("visit_penthouse")
            null height 8
            hbox:
                spacing 10
                textbutton "PHONE / MESSAGES" action Jump("phone_menu")
                textbutton "INVENTORY" action Jump("inventory_menu")
                textbutton "BOARD MEETING" action Jump("end_day")

screen phone_screen():
    modal True
    frame:
        xalign 0.5
        yalign 0.5
        xsize 760
        background "#101722"
        padding (28, 24)
        vbox:
            spacing 12
            text "ADRIAN'S PHONE" size 30 color "#d9c4a0"
            text "Messages" size 20 color "#a8c5c8"
            for msg in messages:
                text msg size 17
            text "Contacts / relationship status" size 20 color "#a8c5c8"
            for name, score in relationships.items():
                text "[name]: [score]" size 16
            textbutton "CLOSE" action Return()

screen inventory_screen():
    modal True
    frame:
        xalign 0.5
        yalign 0.5
        xsize 680
        background "#101722"
        padding (28, 24)
        vbox:
            spacing 12
            text "INVENTORY & EVIDENCE" size 28 color "#d9c4a0"
            text "Items" color "#a8c5c8"
            for item in inventory:
                text "• [item]"
            text "Clues" color "#a8c5c8"
            if len(clues) == 0:
                text "No clues collected."
            else:
                for clue in clues:
                    text "• [clue]"
            textbutton "CLOSE" action Return()

screen wardrobe_screen():
    modal True
    frame:
        xalign 0.5
        yalign 0.5
        background "#101722"
        padding (24, 20)
        vbox:
            spacing 10
            text "WARDROBE" size 28 color "#d9c4a0"
            text "Current look: Executive charcoal suit"
            textbutton "Keep current outfit" action Return()
            textbutton "Close" action Return()

screen preferences():
    use game_menu(_("Preferences")):
        vbox:
            label _("Display")
            textbutton _("Window") action Preference("display", "window")
            textbutton _("Fullscreen") action Preference("display", "fullscreen")
            label _("Text speed")
            bar value Preference("text speed")
            label _("Auto-forward time")
            bar value Preference("auto-forward time")


screen main_menu():
    tag menu
    add Solid("#0d111b")
    vbox:
        xalign 0.5
        yalign 0.5
        spacing 18
        text "ADRIAN: AFTER DARK" size 42 color "#d9c4a0" xalign 0.5
        text "SANDBOX EDITION" size 20 color "#a8c5c8" xalign 0.5
        textbutton "NEW GAME" action Start() xalign 0.5
        textbutton "LOAD GAME" action ShowMenu("load") xalign 0.5
        textbutton "PREFERENCES" action ShowMenu("preferences") xalign 0.5
        textbutton "QUIT" action Quit(confirm=True) xalign 0.5

screen game_menu(title, scroll=None, yinitial=0.0):
    tag menu
    add Solid("#0d111b")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 1080
        ysize 620
        background "#171d29"
        padding (30, 24)
        vbox:
            spacing 18
            text title size 34 color "#d9c4a0"
            transclude
            textbutton "BACK" action Return()

screen navigation():
    vbox:
        spacing 8
        textbutton "Return" action Return()
        textbutton "Save" action ShowMenu("save")
        textbutton "Load" action ShowMenu("load")
        textbutton "Preferences" action ShowMenu("preferences")
        textbutton "Main Menu" action MainMenu()

screen save():
    use game_menu(_("Save")):
        text "Use the Ren'Py save slots below." color "#e7e2d8"
        textbutton "Return to game" action Return()

screen load():
    use game_menu(_("Load")):
        text "Use the Ren'Py load menu from the standard game interface." color "#e7e2d8"
        textbutton "Return to game" action Return()

screen quick_menu():
    zorder 100
    if not main_menu:
        hbox:
            xalign 0.99
            yalign 0.99
            spacing 10
            textbutton "Save" action ShowMenu("save")
            textbutton "Phone" action Jump("phone_menu")
            textbutton "Inventory" action Jump("inventory_menu")
