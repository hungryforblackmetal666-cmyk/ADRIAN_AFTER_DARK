define config.name = _("ADRIAN: AFTER DARK – SANDBOX EDITION")
define gui.show_name = True
define config.version = "1.0"
define build.name = "ADRIAN_AFTER_DARK_v1_0"
define config.save_directory = "AdrianAfterDark-1.0"
define config.has_sound = True
define config.has_music = True
define config.has_voice = False
define config.main_menu_music = None
define config.window = "auto"
define config.rollback_enabled = True
define config.developer = False
define config.screen_width = 1280
define config.screen_height = 720

init python:
    config.default_music_volume = 0.7
    config.default_sfx_volume = 0.8
    config.default_voice_volume = 0.8
