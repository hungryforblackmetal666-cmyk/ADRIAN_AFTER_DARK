SYSTEMS IN V1.0
- Time/day and energy: script.rpy (advance_time)
- Relationship values: relationships dictionary
- Clues and inventory: clues / inventory lists
- Phone: messages list and phone_screen
- Economy: money variable
- Reputation / suspicion: integer variables
- Save/load: Ren'Py built-in save system (Esc/menu)
